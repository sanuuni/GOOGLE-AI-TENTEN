

import React from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import ServicesPage from './pages/ServicesPage';
import AboutUsPage from './pages/AboutUsPage';
import ContactPage from './pages/ContactPage';
import PricingPage from './pages/PricingPage';
import BookingPage from './pages/BookingPage';
import RegistrationPage from './pages/RegistrationPage';
import NotFoundPage from './pages/NotFoundPage';
import PrivacyPolicyPage from './pages/PrivacyPolicyPage';
import TermsPage from './pages/TermsPage';
import ChatWidget from './components/ChatWidget';
import AdPopup from './components/AdPopup';
import ScrollToTop from './components/ScrollToTop';
import QuizPage from './pages/QuizPage'; // Import QuizPage

const App: React.FC = () => {
  return (
    <Router>
      <div className="min-h-screen flex flex-col bg-blue-50 relative">
        <Header />
        <main className="flex-grow flex flex-col">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/services" element={<ServicesPage />} />
            <Route path="/pricing" element={<PricingPage />} />
            <Route path="/booking" element={<BookingPage />} />
            <Route path="/registration" element={<RegistrationPage />} />
            <Route path="/quiz" element={<QuizPage />} /> {/* New route for QuizPage */}
            <Route path="/about" element={<AboutUsPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/privacy" element={<PrivacyPolicyPage />} />
            <Route path="/terms" element={<TermsPage />} />
            {/* Catch-all route for 404 */}
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </main>
        <Footer />
        <ChatWidget />
        <AdPopup />
        <ScrollToTop />
      </div>
    </Router>
  );
};

export default App;