
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Button from './Button';

const AdPopup: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user has already seen the ad in this session
    const hasSeenAd = sessionStorage.getItem('hasSeenAd');
    
    // Only show if they haven't seen it yet
    if (!hasSeenAd) {
      const timer = setTimeout(() => {
        setIsOpen(true);
      }, 2000); // Show after 2 seconds
      return () => clearTimeout(timer);
    }
  }, []);

  const handleClose = () => {
    setIsOpen(false);
    sessionStorage.setItem('hasSeenAd', 'true'); // Remember that user closed it
  };

  const handleClaim = () => {
    setIsOpen(false);
    sessionStorage.setItem('hasSeenAd', 'true');
    navigate('/pricing');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center px-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity" 
        onClick={handleClose}
      ></div>

      {/* Popup Content */}
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full relative z-10 overflow-hidden transform transition-all animate-fade-in-up border-4 border-yellow-300">
        {/* Close Button */}
        <button 
          onClick={handleClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 focus:outline-none bg-white rounded-full p-1 shadow-sm"
          aria-label="Close"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        {/* Header / Image Area */}
        <div className="bg-gradient-to-r from-blue-700 to-blue-900 p-8 text-center text-white relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full opacity-10 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
          <h2 className="text-3xl md:text-4xl font-extrabold mb-2 relative z-10">Limited Time Offer!</h2>
          <p className="text-blue-100 text-lg relative z-10">Don't miss out on our special promotion.</p>
        </div>

        {/* Body */}
        <div className="p-8 text-center">
          <div className="mb-6">
            <span className="inline-block bg-yellow-100 text-yellow-800 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wide mb-2">
              Exclusive Deal
            </span>
            <h3 className="text-4xl font-extrabold text-gray-800 mb-2">
              <span className="text-green-600">10% OFF</span>
            </h3>
            <p className="text-xl font-medium text-gray-600">All Driving Packages</p>
          </div>
          
          <p className="text-gray-600 mb-8 leading-relaxed">
            Start your journey to becoming a confident driver today. Book any package now and secure your discount!
          </p>

          <div className="flex flex-col gap-3">
            <Button onClick={handleClaim} variant="primary" fullWidth className="text-lg py-4 shadow-lg bg-gradient-to-r from-blue-600 to-blue-800 hover:from-blue-700 hover:to-blue-900 border-none">
              Claim My 10% Discount
            </Button>
            <button 
              onClick={handleClose}
              className="text-sm text-gray-400 hover:text-gray-600 underline mt-2"
            >
              No thanks, I'll pay full price
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdPopup;
