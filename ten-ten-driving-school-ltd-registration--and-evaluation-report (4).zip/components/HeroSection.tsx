
import React from 'react';
import { useNavigate } from 'react-router-dom';
import Button from './Button';

const HeroSection: React.FC = () => {
  const navigate = useNavigate();

  const handleBookNowClick = () => {
    navigate('/pricing');
  };

  return (
    <section
      className="relative h-screen-3/4 flex items-center justify-center text-center p-4"
      style={{
        backgroundImage: `url('https://images.unsplash.com/photo-1549465223-b1c034608c06?q=80&w=2940&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D')`, // Placeholder driving school image
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      {/* Gradient overlay for colors */}
      <div className="absolute inset-0 bg-gradient-to-r from-blue-700 via-orange-500 to-white opacity-40"></div>
      {/* Darkening overlay for text readability */}
      <div className="absolute inset-0 bg-black opacity-60"></div>
      <div className="relative z-10 text-white max-w-4xl mx-auto">
        <h1 className="text-4xl md:text-6xl font-extrabold leading-tight mb-6">
          Learn to Drive Safely and Confidently
        </h1>
        <p className="text-lg md:text-2xl mb-8 font-light">
          Expert instructors and easy-to-understand programs for every new driver.
        </p>
        <Button onClick={handleBookNowClick} variant="primary" className="text-xl px-10 py-4">
          Book Your Lesson Now!
        </Button>
      </div>
    </section>
  );
};

export default HeroSection;