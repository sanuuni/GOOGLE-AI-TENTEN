import React from 'react';
import { useNavigate } from 'react-router-dom';
import Button from './Button';

const PromoBanner: React.FC = () => {
  const navigate = useNavigate();

  const handleBookNowClick = () => {
    navigate('/pricing'); // Changed target to '/pricing'
  };

  return (
    <section className="bg-gradient-to-r from-yellow-300 via-white to-green-300 py-12 px-4 text-center shadow-lg">
      <div className="container mx-auto">
        <h2 className="text-4xl md:text-5xl font-extrabold mb-4 animate-pulse text-blue-800">
          🎉 Get <span className="text-green-700">10% OFF</span> All Driving Packages! 🎉
        </h2>
        <p className="text-lg md:text-xl mb-8 font-light text-gray-700">
          Limited time offer. Start your driving journey today and save big!
        </p>
        <Button onClick={handleBookNowClick} variant="primary" className="text-xl px-10 py-4 !bg-blue-700 !text-white hover:!bg-blue-800">
          Book Now
        </Button>
      </div>
    </section>
  );
};

export default PromoBanner;