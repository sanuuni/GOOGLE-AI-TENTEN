

export const SCHOOL_NAME = "Ten Ten Driving School";

export const NAV_LINKS = [
  { name: "Home", path: "/" },
  { name: "Services", path: "/services" },
  { name: "Pricing", path: "/pricing" },
  { name: "Booking", path: "/booking" },
  { name: "Registration", path: "/registration" },
  { name: "Driving Quiz", path: "/quiz" }, // New Driving Quiz link
  { name: "About Us", path: "/about" },
  { name: "Contact", path: "/contact" },
];

export const BOOKING_LINK = "https://calendly.com/tentendrivingschool/tentendrivingschool";