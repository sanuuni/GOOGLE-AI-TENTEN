
import React from 'react';
import { Link } from 'react-router-dom'; // Import Link
import { SCHOOL_NAME } from '../constants';

const AboutUsPage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8 flex-grow">
      <h1 className="text-5xl font-extrabold text-blue-800 text-center mb-12">About {SCHOOL_NAME}</h1>

      <div className="bg-white rounded-lg shadow-xl p-8 border border-blue-100 mb-10">
        <h2 className="text-3xl font-bold text-blue-700 mb-4">Our Mission</h2>
        <p className="text-gray-700 leading-relaxed text-lg">
          At {SCHOOL_NAME}, our mission is to empower every student with the knowledge, skills, and confidence to become a safe, responsible, and proficient driver. We believe that proper driving education is the foundation for a lifetime of safe travel, and we are committed to instilling best practices and defensive driving techniques in all our learners.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-10 mb-10">
        <div className="bg-white rounded-lg shadow-xl p-8 border border-blue-100">
          <h3 className="text-3xl font-bold text-blue-700 mb-4">Our Values</h3>
          <ul className="list-disc list-inside text-gray-700 space-y-3 text-lg">
            <li><strong>Safety First:</strong> Prioritizing the safety of our students and all road users.</li>
            <li><strong>Professionalism:</strong> Delivering high-quality instruction with respect and integrity.</li>
            <li><strong>Patience & Empathy:</strong> Understanding that every student learns at their own pace.</li>
            <li><strong>Excellence:</strong> Striving for the highest standards in driving education.</li>
            <li><strong>Community:</strong> Contributing to safer roads for everyone in our community.</li>
          </ul>
        </div>
        <div className="bg-white rounded-lg shadow-xl p-8 border border-blue-100">
          <h3 className="text-3xl font-bold text-blue-700 mb-4">Our History</h3>
          <p className="text-gray-700 leading-relaxed text-lg mb-4">
            Founded in [Year, e.g., 2010], {SCHOOL_NAME} started with a simple goal: to make driver education accessible, effective, and enjoyable. Over the years, we have grown from a small local school to a trusted institution, helping thousands of students achieve their driving goals.
          </p>
          <p className="text-gray-700 leading-relaxed text-lg">
            Our commitment to innovative teaching methods, continuous instructor training, and maintaining a modern fleet of vehicles has made us a leader in driving instruction. We are proud of our legacy and excited for the future as we continue to help new drivers hit the road safely.
          </p>
        </div>
      </div>

      <div className="bg-blue-50 rounded-lg shadow-inner p-8 text-center">
        <h3 className="text-3xl font-bold text-blue-800 mb-4">Meet Our Team</h3>
        <p className="text-gray-700 leading-relaxed text-lg max-w-2xl mx-auto">
          Our team of dedicated and certified driving instructors are at the heart of our success. With years of experience and a passion for teaching, they provide personalized instruction to ensure every student feels confident and prepared.
          Learn more about our instructors during your enrollment!
        </p>
        <div className="mt-8">
          <Link to="/contact" className="inline-block bg-blue-700 text-white text-xl px-8 py-3 rounded-lg font-semibold hover:bg-blue-800 transition-colors duration-200">
            Join Our Driving Family
          </Link>
        </div>
      </div>
    </div>
  );
};

export default AboutUsPage;