
import React from 'react';
import { Link } from 'react-router-dom'; // Import Link
import { BOOKING_LINK } from '../constants';

const BookingPage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8 flex-grow">
      <h1 className="text-5xl font-extrabold text-blue-800 text-center mb-12">Schedule Your Driving Lesson</h1>
      <p className="text-xl text-gray-700 text-center mb-10 max-w-3xl mx-auto">
        Ready to hit the road? Use our calendar below to find a time that works best for your driving lessons.
      </p>
      <div className="flex justify-center">
        <iframe
          src={BOOKING_LINK}
          width="100%"
          height="800px" // Increased height to better display the calendar
          frameBorder="0"
          className="rounded-lg shadow-xl border border-blue-100 max-w-4xl w-full min-h-[80vh]"
          title="Ten Ten Driving School Booking"
        ></iframe>
      </div>
      <div className="mt-12 text-center bg-blue-50 p-8 rounded-lg shadow-md">
        <h2 className="text-3xl font-bold text-blue-800 mb-4">Can't find a suitable time?</h2>
        <p className="text-xl text-gray-700 mb-6 max-w-2xl mx-auto">
          Don't hesitate to reach out to us directly, and we'll do our best to accommodate you.
        </p>
        <Link to="/contact" className="inline-block bg-blue-700 text-white text-xl px-8 py-3 rounded-lg font-semibold hover:bg-blue-800 transition-colors duration-200">
          Contact Us
        </Link>
      </div>
    </div>
  );
};

export default BookingPage;