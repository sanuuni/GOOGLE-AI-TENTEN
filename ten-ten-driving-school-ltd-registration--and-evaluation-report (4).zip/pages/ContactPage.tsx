
import React, { useState } from 'react';
import Button from '../components/Button';
import { SCHOOL_NAME } from '../constants';

const ContactPage: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '', // Added address field
    message: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real application, you would send this data to a backend.
    console.log('Form submitted:', formData);
    alert('Thank you for your message! We will get back to you shortly.');
    setFormData({ name: '', email: '', phone: '', address: '', message: '' }); // Clear form
  };

  return (
    <div className="container mx-auto px-4 py-8 flex-grow">
      <h1 className="text-5xl font-extrabold text-blue-800 text-center mb-12">Contact {SCHOOL_NAME}</h1>
      <p className="text-xl text-gray-700 text-center mb-10 max-w-3xl mx-auto">
        Have questions about our driving lessons, pricing, or scheduling? Reach out to us using the form below, or find our contact details. We're here to help!
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        {/* Contact Form */}
        <div className="bg-white rounded-lg shadow-xl p-8 border border-blue-100">
          <h2 className="text-3xl font-bold text-blue-700 mb-6">Send Us a Message</h2>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="name" className="block text-gray-700 text-lg font-semibold mb-2">
                Your Name
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 text-lg"
                placeholder="John Doe"
                required
              />
            </div>
            <div>
              <label htmlFor="email" className="block text-gray-700 text-lg font-semibold mb-2">
                Your Email
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 text-lg"
                placeholder="john.doe@example.com"
                required
              />
            </div>
            <div>
              <label htmlFor="phone" className="block text-gray-700 text-lg font-semibold mb-2">
                Phone Number (Optional)
              </label>
              <input
                type="tel"
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 text-lg"
                placeholder="(123) 456-7890"
              />
            </div>
            <div>
              <label htmlFor="address" className="block text-gray-700 text-lg font-semibold mb-2">
                Your Address
              </label>
              <input
                type="text"
                id="address"
                name="address"
                value={formData.address}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 text-lg"
                placeholder="Your Full Address"
                required
              />
            </div>
            <div>
              <label htmlFor="message" className="block text-gray-700 text-lg font-semibold mb-2">
                Your Message
              </label>
              <textarea
                id="message"
                name="message"
                rows={5}
                value={formData.message}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 text-lg resize-y"
                placeholder="Tell us how we can help you..."
                required
              ></textarea>
            </div>
            <Button type="submit" fullWidth={true}>
              Send Message
            </Button>
          </form>
        </div>

        {/* Contact Information */}
        <div className="bg-blue-50 rounded-lg shadow-xl p-8 border border-blue-100">
          <h2 className="text-3xl font-bold text-blue-700 mb-6">Our Information</h2>
          <div className="space-y-6 text-lg text-gray-700">
            <div>
              <h3 className="font-semibold text-blue-800 mb-2">Phone:</h3>
              <p>
                <a href="tel:+14034041010" className="text-blue-600 hover:underline">+1 (403) 404-1010</a>
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-blue-800 mb-2">Email:</h3>
              <p>
                <a href="mailto:sankatenten@gmail.com" className="text-blue-600 hover:underline">sankatenten@gmail.com</a>
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-blue-800 mb-2">Office Hours:</h3>
              <p>Monday - Saturday: 9:00 AM - 8:00 PM</p>
              <p>Sunday: 9:00 AM - 5:00 PM</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;