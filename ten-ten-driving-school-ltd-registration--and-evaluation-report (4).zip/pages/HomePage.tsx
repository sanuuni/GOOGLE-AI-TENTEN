

import React, { useState } from 'react'; // Import useState
import { useNavigate } from 'react-router-dom';
import HeroSection from '../components/HeroSection';
import PromoBanner from '../components/PromoBanner'; // Import PromoBanner
import Button from '../components/Button'; // Import Button
import { SCHOOL_NAME } from '../constants';

const HomePage: React.FC = () => {
  const navigate = useNavigate(); // Initialize useNavigate

  const handleBookYourLessonClick = () => {
    navigate('/pricing'); // Navigate to pricing page
  };

  // FAQ Data (subset from ResourcesPage for general questions)
  const faqs = [
    {
      question: "How do I get my Insurance Reduction Certificate?",
      answer: "To qualify for the insurance reduction certificate, you must successfully complete our 'Package A' or 'Package D' course, which consists of at least 15 hours of classroom (online) instruction and 10 hours of in-vehicle training, achieving a passing grade."
    },
    {
      question: "Can I use the driving school car for my road test?",
      answer: "Yes! We offer packages that include car rental for your road test. This is a great option as you will be taking the test in the same vehicle you trained in, which can significantly reduce stress."
    },
    {
      question: "Do you offer pickup and drop-off?",
      answer: "Yes, we offer complimentary pickup and drop-off for our in-vehicle lessons within North West Calgary. If you live outside this area, we can arrange a convenient meeting point."
    },
    {
      question: "How long does the full course take to complete?",
      answer: "The timeline depends on your availability. The online classroom portion is self-paced (approx. 15 hours). The 10 hours of driving can be scheduled at your convenience. Most students complete the full program within 4-8 weeks."
    }
  ];

  const [openIndex, setOpenIndex] = useState<number | null>(null); // State for FAQ toggling

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };


  return (
    <div className="flex-grow">
      <HeroSection />

      {/* New Promo Banner */}
      <PromoBanner />

      {/* New Introduction Section */}
      <section className="py-16 bg-blue-100">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-blue-800 mb-4">Welcome to {SCHOOL_NAME}</h2>
          <p className="text-xl text-gray-700 mb-8 max-w-4xl mx-auto">
            Your trusted partner in becoming a skilled, confident, and safe driver. We are committed to providing top-tier driving education tailored to your needs, ensuring you master the road with ease.
          </p>
          <Button onClick={() => navigate('/services')} variant="primary" className="text-lg px-8 py-3">
            Explore Our Services
          </Button>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-blue-800 mb-4">Why Choose {SCHOOL_NAME}?</h2>
          <p className="text-xl text-gray-700 mb-12 max-w-3xl mx-auto">
            We are dedicated to providing the highest quality driving education, ensuring you become a confident and safe driver for life.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-8 border border-blue-200 rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300">
              <h3 className="text-2xl font-semibold text-blue-700 mb-4">Experienced Instructors</h3>
              <p className="text-gray-600">
                Learn from certified professionals who are passionate about teaching and committed to your success.
              </p>
            </div>
            <div className="p-8 border border-blue-200 rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300">
              <h3 className="text-2xl font-semibold text-blue-700 mb-4">Flexible Scheduling</h3>
              <p className="text-gray-600">
                We offer a variety of scheduling options to fit your busy lifestyle, including evenings and weekends.
              </p>
            </div>
            <div className="p-8 border border-blue-200 rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300">
              <h3 className="text-2xl font-semibold text-blue-700 mb-4">Modern Vehicles</h3>
              <p className="text-gray-600">
                Train in safe, well-maintained, dual-control vehicles equipped with the latest safety features.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* More Than Just Driving Lessons advertisement section */}
      <section className="py-16 bg-blue-50">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-blue-800 mb-4">More Than Just Driving Lessons: Your Road to Confidence</h2>
          <p className="text-xl text-gray-700 mb-8 max-w-4xl mx-auto">
            At {SCHOOL_NAME}, we believe that learning to drive is a journey of empowerment. Our programs go beyond just passing a test; we focus on developing confident, responsible, and defensive drivers ready for any road challenge. We understand that every student has unique learning needs, which is why our certified instructors provide personalized, patient, and engaging lessons.
          </p>
          <p className="text-xl text-gray-700 mb-12 max-w-4xl mx-auto">
            From your very first lesson to advanced defensive driving techniques, we equip you with real-world skills in a supportive environment. Drive with peace of mind knowing you're learning from the best, in modern, safe, dual-control vehicles. Your safety and success are our top priorities.
          </p>
          <Button onClick={() => navigate('/about')} variant="primary" className="text-lg px-8 py-3">
            Learn More About Us
          </Button>
        </div>
      </section>

      {/* Testimonials Section - NEW */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-blue-800 mb-12">Student Success Stories</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: "Sarah M.",
                text: "I passed my road test on the first try! The instructors were so patient and helpful. I highly recommend Ten Ten Driving School.",
                stars: 5
              },
              {
                name: "James K.",
                text: "The flexible scheduling made it easy to fit lessons around my school work. Great experience overall!",
                stars: 5
              },
              {
                name: "Emily R.",
                text: "I was very nervous about driving, but my instructor helped me build confidence. The 'Brush Up' course was exactly what I needed.",
                stars: 5
              }
            ].map((review, index) => (
              <div key={index} className="bg-gray-50 p-6 rounded-lg shadow-md border border-gray-100">
                <div className="flex justify-center mb-4">
                  {[...Array(review.stars)].map((_, i) => (
                    <svg key={i} className="w-6 h-6 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                <p className="text-gray-700 italic mb-4">"{review.text}"</p>
                <p className="font-bold text-blue-800">- {review.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section - NEW */}
      <section className="py-16 bg-blue-50">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-blue-800 text-center mb-12">Frequently Asked Questions</h2>
          <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-lg p-8 border border-gray-200">
            <div className="space-y-4">
              {faqs.map((faq, index) => (
                <div key={index} className="border-b border-gray-200 pb-4 last:border-0">
                  <button
                    className="w-full flex justify-between items-center text-left focus:outline-none"
                    onClick={() => toggleFAQ(index)}
                    aria-expanded={openIndex === index}
                    aria-controls={`faq-answer-${index}`}
                  >
                    <span className="text-xl font-semibold text-gray-800 hover:text-blue-700 transition-colors">{faq.question}</span>
                    <span className={`transform transition-transform duration-200 ${openIndex === index ? 'rotate-180' : ''}`}>
                      <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                    </span>
                  </button>
                  {openIndex === index && (
                    <div id={`faq-answer-${index}`} className="mt-4 text-gray-700 leading-relaxed bg-blue-50 p-4 rounded-lg">
                      {faq.answer}
                    </div>
                  )}
                </div>
              ))}
            </div>
            {/* Removed the "View All Resources" button */}
          </div>
        </div>
      </section>


      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-blue-800 mb-4">Ready to Get Started?</h2>
          <p className="text-xl text-gray-700 mb-8 max-w-3xl mx-auto">
            Enroll today and take the first step towards obtaining your driver's license with confidence.
          </p>
          <Button onClick={handleBookYourLessonClick} variant="primary" className="text-xl px-10 py-4">
            Book Your Lesson Now
          </Button>
        </div>
      </section>
    </div>
  );
};

export default HomePage;