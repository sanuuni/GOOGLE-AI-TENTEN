
import React from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../components/Button';

const NotFoundPage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="flex-grow flex flex-col items-center justify-center text-center p-4 bg-gray-50">
      <h1 className="text-9xl font-extrabold text-blue-200">404</h1>
      <h2 className="text-4xl font-bold text-blue-800 mb-4">Page Not Found</h2>
      <p className="text-xl text-gray-600 mb-8 max-w-lg">
        Oops! It looks like you've taken a wrong turn. The page you are looking for doesn't exist or has been moved.
      </p>
      <div className="flex gap-4">
        <Button onClick={() => navigate('/')} variant="primary" className="px-8 py-3">
          Go Back Home
        </Button>
        <Button onClick={() => navigate('/contact')} variant="secondary" className="px-8 py-3">
          Contact Support
        </Button>
      </div>
    </div>
  );
};

export default NotFoundPage;
