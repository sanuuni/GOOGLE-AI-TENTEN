
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom'; // Import useNavigate
import Button from '../components/Button';
import { BOOKING_LINK } from '../constants'; // Import BOOKING_LINK

interface PricingPackage {
  name: string;
  description: string;
  price: string;
  isPopular?: boolean;
  features: string[];
  icon: React.ReactNode; // Added icon property
  colorTheme: string; // Added color theme for card headers
}

const rawPricingPackages: Omit<PricingPackage, 'price' | 'features' | 'icon' | 'colorTheme'>[] = [
    // We will map over the data to add styling properties, keeping raw data here for reference if needed
    // But since we are adding icons, let's reconstruct the array fully below.
];

// Helper to extract numerical price for sorting
const getNumericPrice = (priceString: string): number => {
  const match = priceString.match(/\$(\d+)/);
  return match ? parseInt(match[1], 10) : 0;
};

// Define packages with Icons and Themes
const definedPackages: PricingPackage[] = [
  {
    name: "Full Course",
    description: "15 Hours Online Class + 10 Hours In-Car Driving Training",
    price: "$729 + GST",
    isPopular: true,
    colorTheme: "blue",
    icon: (
      <svg className="w-12 h-12 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M12 14l9-5-9-5-9 5 9 5z"></path>
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z"></path>
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M12 14l9-5-9-5-9 5 9 5zm0 0l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14zm-4 6v-7.5l4-2.222"></path>
      </svg>
    ),
    features: [
      "Comprehensive online theory",
      "10 hours practical driving",
      "Certified instructors",
      "Flexible scheduling",
      "Road test preparation",
      "Includes pickup and drop-off in North West Calgary"
    ]
  },
  {
    name: "Vehicle Training Only",
    description: "10 Hours In-Car Driving Training",
    price: "$625 + GST",
    colorTheme: "green",
    icon: (
      <svg className="w-12 h-12 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"></path>
      </svg>
    ),
    features: [
      "10 hours practical driving",
      "Focus on driving techniques",
      "Experienced instructors",
      "Perfect for those with permit",
      "Includes pickup and drop-off in North West Calgary"
    ]
  },
  {
    name: "6 Hours Brush Up Lesson",
    description: "6 Hours In-Car Driving Training",
    price: "$385 + GST",
    colorTheme: "teal",
    icon: (
      <svg className="w-12 h-12 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
      </svg>
    ),
    features: [
      "In-depth skill enhancement",
      "Multiple sessions",
      "Build confidence",
      "Personalized instruction",
      "Includes pickup and drop-off in North West Calgary"
    ]
  },
  {
    name: "Advanced Maneuvers Course",
    description: "4 Hours In-Car Training for Advanced Skills",
    price: "$255 + GST",
    colorTheme: "indigo",
    icon: (
      <svg className="w-12 h-12 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
      </svg>
    ),
    features: [
      "4 hours specialized training",
      "Parallel parking, 3-point turns",
      "Urban and highway strategies",
      "Experienced instructors",
      "Includes pickup and drop-off in North West Calgary"
    ] // Restored features
  },
  {
    name: "2 Hours Training + Car Rental",
    description: "2 Hours Training + Car Rental for Road Test",
    price: "$210 + GST",
    colorTheme: "orange",
    icon: (
       <svg className="w-12 h-12 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"></path>
       </svg>
    ),
    features: [
      "2 hours pre-test training",
      "Car rental for road test",
      "Familiar vehicle for test",
      "Boosts test confidence"
    ]
  },
  {
    name: "1 Hour Training + Car Rental",
    description: "1 Hour Training + Car Rental for Road Test",
    price: "$149 + GST",
    colorTheme: "orange",
    icon: (
      <svg className="w-12 h-12 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
      </svg>
    ),
    features: [
      "1 hour pre-test training",
      "Car rental for road test",
      "Last-minute tips",
      "Convenient for test day"
    ]
  },
  {
    name: "2 Hours Brush Up Lesson",
    description: "2 Hours In-Car Driving Training",
    price: "$130 + GST",
    colorTheme: "teal",
    icon: (
      <svg className="w-12 h-12 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
      </svg>
    ),
    features: [
      "Quick skill refinement",
      "Target specific weaknesses",
      "Ideal before a road test",
      "Flexible timing",
      "Includes pickup and drop-off in North West Calgary"
    ]
  },
  {
    name: "Car Rental Only",
    description: "Car Rental for the Road Test",
    price: "$80 + GST",
    colorTheme: "gray",
    icon: (
      <svg className="w-12 h-12 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"></path>
      </svg>
    ),
    features: [
      "Reliable vehicle for test",
      "Ensures vehicle compliance",
      "Stress-free test day"
    ]
  },
];

// Sort pricing packages from highest to lowest price
const pricingPackages: PricingPackage[] = [...definedPackages].sort((a, b) => {
  const priceA = getNumericPrice(a.price);
  const priceB = getNumericPrice(b.price);
  return priceB - priceA; // Descending order
});

const PricingPage: React.FC = () => {
  const [showBookingModal, setShowBookingModal] = useState(false);
  const navigate = useNavigate();

  const handleEnrollClick = () => {
    setShowBookingModal(true);
  };

  const handleConfirmBooking = () => {
    navigate('/booking'); 
    setShowBookingModal(false);
  };

  const handleCloseModal = () => {
    setShowBookingModal(false);
  };

  const getThemeClasses = (theme: string, isPopular?: boolean) => {
    switch(theme) {
      case 'blue': return 'bg-blue-600';
      case 'green': return 'bg-green-600';
      case 'teal': return 'bg-teal-600';
      case 'indigo': return 'bg-indigo-600';
      case 'orange': return 'bg-orange-500';
      default: return 'bg-gray-600';
    }
  };

  return (
    <div className="bg-gray-50 flex-grow">
        {/* Header Section */}
        <div className="bg-blue-800 text-white py-16 px-4 text-center">
            <h1 className="text-4xl md:text-5xl font-extrabold mb-4">Invest in Your Safety</h1>
            <p className="text-xl md:text-2xl font-light text-blue-100 max-w-3xl mx-auto">
                Transparent pricing for every stage of your driving journey. No hidden fees.
            </p>
        </div>

      <div className="container mx-auto px-4 py-12 -mt-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {pricingPackages.map((pkg, index) => (
            <div
              key={index}
              className={`bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 flex flex-col relative overflow-hidden ${
                pkg.isPopular ? 'transform md:-translate-y-4 border-2 border-yellow-400 ring-4 ring-yellow-100 z-10' : 'border border-gray-100'
              }`}
            >
              {pkg.isPopular && (
                <div className="absolute top-4 right-0 bg-yellow-400 text-blue-900 text-xs font-bold px-3 py-1 rounded-l-md shadow-sm uppercase tracking-wide">
                  Most Popular
                </div>
              )}
              
              {/* Card Header with Icon */}
              <div className={`${getThemeClasses(pkg.colorTheme)} p-6 flex justify-center items-center`}>
                 <div className="bg-white/20 p-3 rounded-full backdrop-blur-sm">
                    {pkg.icon}
                 </div>
              </div>

              <div className="p-8 flex-grow flex flex-col">
                <h2 className="text-2xl font-bold text-gray-800 mb-2 text-center h-16 flex items-center justify-center leading-tight">
                    {pkg.name}
                </h2>
                <div className="text-center mb-6">
                  <div className="text-4xl font-extrabold text-blue-800 flex items-center justify-center">
                    {pkg.price.split('+')[0].trim()}
                    <span className="text-lg text-gray-500 font-medium ml-1"> + GST</span>
                  </div>
                </div>
                
                <p className="text-gray-600 text-sm text-center mb-6 px-4 italic border-b border-gray-100 pb-4">
                    {pkg.description}
                </p>

                <ul className="text-gray-700 space-y-3 mb-8 flex-grow">
                  {pkg.features.map((feature, i) => (
                    <li key={i} className="flex items-start text-sm md:text-base">
                      <svg className="w-5 h-5 text-green-500 mr-3 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      {feature}
                    </li>
                  ))}
                </ul>

                <div className="mt-auto space-y-3">
                  <Button fullWidth={true} onClick={handleEnrollClick} className={`${pkg.isPopular ? 'bg-blue-700 hover:bg-blue-800 shadow-md' : ''}`}>
                    Book Now
                  </Button>
                  
                  <a 
                    href={`https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=sankatenten@gmail.com&item_name=${encodeURIComponent(pkg.name)}&amount=${getNumericPrice(pkg.price)}&currency_code=CAD&tax_rate=5`}
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="w-full py-3 px-6 rounded-lg font-bold transition-all duration-200 bg-[#FFC439] hover:bg-[#F4B725] text-blue-900 flex items-center justify-center shadow-sm hover:shadow-md group"
                  >
                    <span className="italic mr-1">Pay</span><span className="italic text-blue-800 group-hover:text-blue-900">Pal</span>
                    <svg className="w-4 h-4 ml-2 opacity-70" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-20 text-center bg-white p-10 rounded-2xl shadow-md border border-gray-100 max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-blue-800 mb-4">Need help choosing?</h2>
          <p className="text-lg text-gray-600 mb-8">
            Our team is happy to help you choose the best driving program for your specific needs and experience level.
          </p>
          <div className="flex justify-center gap-4 flex-wrap">
             <Link to="/contact">
                <Button variant="secondary" className="px-8 py-3">
                    Contact Us
                </Button>
            </Link>
            <Link to="/booking">
                <Button variant="primary" className="px-8 py-3">
                    View Schedule
                </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Booking Confirmation Modal */}
      {showBookingModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" role="dialog" aria-modal="true">
          <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full mx-auto animate-fade-in-up">
            <div className="text-center mb-6">
                <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                </div>
                <h2 className="text-2xl font-bold text-gray-800">Confirm Booking</h2>
            </div>
            <p className="text-gray-600 mb-8 text-center leading-relaxed">
              You are being redirected to our scheduling calendar. Please select your preferred date and time.
            </p>
            <div className="flex flex-col space-y-3">
              <Button onClick={handleConfirmBooking} fullWidth={true} className="text-lg py-3 shadow-lg">
                Continue to Calendar
              </Button>
              <button 
                onClick={handleCloseModal} 
                className="w-full py-3 text-gray-500 font-semibold hover:text-gray-700 transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PricingPage;