
import React from 'react';
import { SCHOOL_NAME } from '../constants';

const PrivacyPolicyPage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8 flex-grow">
      <div className="max-w-4xl mx-auto bg-white p-8 md:p-12 shadow-md border border-gray-100 rounded-lg">
        <h1 className="text-4xl font-extrabold text-blue-800 mb-8">Privacy Policy</h1>
        <p className="text-gray-600 mb-8 text-sm">Last Updated: {new Date().toLocaleDateString()}</p>

        <div className="space-y-6 text-gray-700 leading-relaxed">
          <section>
            <h2 className="text-2xl font-bold text-blue-700 mb-4">1. Introduction</h2>
            <p>
              Welcome to {SCHOOL_NAME}. We respect your privacy and are committed to protecting your personal data. 
              This privacy policy will inform you as to how we look after your personal data when you visit our website 
              and tell you about your privacy rights and how the law protects you.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-blue-700 mb-4">2. The Data We Collect</h2>
            <p>
              We may collect, use, store and transfer different kinds of personal data about you which we have grouped together follows:
            </p>
            <ul className="list-disc list-inside ml-4 mt-2 space-y-2">
              <li><strong>Identity Data:</strong> includes first name, last name, date of birth, and driver's license information required for registration.</li>
              <li><strong>Contact Data:</strong> includes billing address, delivery address, email address and telephone numbers.</li>
              <li><strong>Transaction Data:</strong> includes details about payments to and from you and other details of products and services you have purchased from us.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-blue-700 mb-4">3. How We Use Your Data</h2>
            <p>
              We will only use your personal data when the law allows us to. Most commonly, we will use your personal data in the following circumstances:
            </p>
            <ul className="list-disc list-inside ml-4 mt-2 space-y-2">
              <li>To register you as a new student.</li>
              <li>To process and deliver your order including: Manage payments, fees and charges.</li>
              <li>To manage our relationship with you which will include: Notifying you about changes to our terms or privacy policy.</li>
              <li>To issue course completion certificates for insurance reduction purposes.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-blue-700 mb-4">4. Data Security</h2>
            <p>
              We have put in place appropriate security measures to prevent your personal data from being accidentally lost, used or accessed in an unauthorized way, altered or disclosed. In addition, we limit access to your personal data to those employees, agents, contractors and other third parties who have a business need to know.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-blue-700 mb-4">5. Contact Details</h2>
            <p>
              If you have any questions about this privacy policy or our privacy practices, please contact us at:
            </p>
            <div className="mt-4 bg-blue-50 p-4 rounded-lg">
              <p><strong>{SCHOOL_NAME}</strong></p>
              <p>Email: sankatenten@gmail.com</p>
              <p>Phone: 403-404-1010</p>
              <p>Address: 4641-128 Ave NE, Calgary, AB T3N 1T5</p>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicyPage;
