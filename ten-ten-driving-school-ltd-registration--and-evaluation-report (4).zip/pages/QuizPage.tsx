
import React, { useState, useEffect } from 'react';
import Button from '../components/Button';
import { GoogleGenAI, Type } from "@google/genai";

interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswerIndex: number; // 0-indexed
}

const quizQuestionSchema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      question: { type: Type.STRING, description: 'The driving theory question.' },
      options: {
        type: Type.ARRAY,
        items: { type: Type.STRING, description: 'A possible answer option.' },
        minItems: 4,
        maxItems: 4,
      },
      correctAnswerIndex: { type: Type.INTEGER, description: 'The 0-indexed position of the correct answer within the options array.', minimum: 0, maximum: 3 },
    },
    required: ["question", "options", "correctAnswerIndex"],
  },
  minItems: 5, // Ensure at least 5 questions
  maxItems: 5, // Ensure exactly 5 questions
};

const QuizPage: React.FC = () => {
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userSelectedAnswers, setUserSelectedAnswers] = useState<number[]>([]); // Array of selected option indices
  const [score, setScore] = useState(0);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [loadingQuestions, setLoadingQuestions] = useState(false);
  const [selectedOptionIndex, setSelectedOptionIndex] = useState<number | null>(null);
  const [quizStarted, setQuizStarted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchQuizQuestions = async () => {
    setLoadingQuestions(true);
    setError(null);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = "Generate exactly 5 distinct multiple-choice questions about general Alberta Class 7 driving theory. Each question must have exactly 4 answer options. The output should be a JSON array where each object contains 'question' (string), 'options' (array of 4 strings), and 'correctAnswerIndex' (number from 0 to 3 indicating the correct option).";
      
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [{ parts: [{ text: prompt }] }],
        config: {
          responseMimeType: "application/json",
          responseSchema: quizQuestionSchema,
        },
      });

      const jsonString = response.text.trim();
      const parsedQuestions: QuizQuestion[] = JSON.parse(jsonString);
      
      if (parsedQuestions.length !== 5 || !parsedQuestions.every(q => q.options.length === 4 && typeof q.correctAnswerIndex === 'number' && q.correctAnswerIndex >= 0 && q.correctAnswerIndex <= 3)) {
        throw new Error("Invalid question format received from API.");
      }

      setQuestions(parsedQuestions);
      setCurrentQuestionIndex(0);
      setUserSelectedAnswers(Array(parsedQuestions.length).fill(null));
      setScore(0);
      setQuizCompleted(false);
      setSelectedOptionIndex(null);
      setQuizStarted(true);
    } catch (e: any) {
      console.error("Error fetching quiz questions:", e);
      setError(`Failed to load quiz questions: ${e.message || 'An unknown error occurred.'}`);
      setQuizStarted(false); // Reset if error occurs during start
    } finally {
      setLoadingQuestions(false);
    }
  };

  const handleOptionSelect = (index: number) => {
    setSelectedOptionIndex(index);
    const newAnswers = [...userSelectedAnswers];
    newAnswers[currentQuestionIndex] = index;
    setUserSelectedAnswers(newAnswers);
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedOptionIndex(userSelectedAnswers[currentQuestionIndex + 1]); // Restore selection if exists
    } else {
      calculateScore();
      setQuizCompleted(true);
      setQuizStarted(false); // Quiz is completed
    }
  };

  const calculateScore = () => {
    let newScore = 0;
    questions.forEach((q, index) => {
      if (userSelectedAnswers[index] === q.correctAnswerIndex) {
        newScore++;
      }
    });
    setScore(newScore);
  };

  const handleRestartQuiz = () => {
    setQuizStarted(false);
    setQuizCompleted(false);
    setQuestions([]);
    setCurrentQuestionIndex(0);
    setUserSelectedAnswers([]);
    setScore(0);
    setSelectedOptionIndex(null);
    setError(null);
  };

  const currentQuestion = questions[currentQuestionIndex];

  return (
    <div className="container mx-auto px-4 py-8 flex-grow">
      <h1 className="text-5xl font-extrabold text-blue-800 text-center mb-12">Driving Knowledge Quiz</h1>

      {!quizStarted && !quizCompleted && !loadingQuestions && !error && (
        <div className="text-center bg-white p-8 rounded-lg shadow-lg max-w-2xl mx-auto border border-blue-100">
          <h2 className="text-3xl font-bold text-gray-800 mb-4">Test Your Road Knowledge!</h2>
          <p className="text-lg text-gray-600 mb-6">
            Think you know Alberta's driving rules? Take our quick 5-question quiz to find out!
          </p>
          <Button onClick={fetchQuizQuestions} variant="primary" className="text-lg px-8 py-3">
            Start Quiz
          </Button>
        </div>
      )}

      {loadingQuestions && (
        <div className="text-center py-10">
          <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-blue-500 mx-auto"></div>
          <p className="text-xl text-gray-700 mt-4">Loading questions...</p>
        </div>
      )}

      {error && (
        <div className="text-center bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative max-w-xl mx-auto" role="alert">
          <strong className="font-bold">Error!</strong>
          <span className="block sm:inline ml-2">{error}</span>
          <div className="mt-4">
            <Button onClick={handleRestartQuiz} variant="secondary">Try Again</Button>
          </div>
        </div>
      )}

      {quizStarted && !quizCompleted && currentQuestion && (
        <div className="bg-white p-8 rounded-lg shadow-lg max-w-3xl mx-auto border border-blue-100">
          <p className="text-blue-600 font-semibold mb-6 text-center text-xl">
            Question {currentQuestionIndex + 1} of {questions.length}
          </p>
          <h2 className="text-2xl font-bold text-gray-800 mb-6 leading-relaxed">
            {currentQuestion.question}
          </h2>
          <div className="space-y-4 mb-8">
            {currentQuestion.options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleOptionSelect(index)}
                className={`w-full text-left p-4 rounded-lg border-2 transition-all duration-200
                  ${selectedOptionIndex === index
                    ? 'bg-blue-100 border-blue-600 text-blue-800 shadow-md'
                    : 'bg-gray-50 border-gray-200 hover:bg-gray-100 text-gray-700 hover:border-blue-300'
                  }`}
              >
                <span className="font-semibold mr-2">{String.fromCharCode(65 + index)}.</span> {option}
              </button>
            ))}
          </div>
          <div className="flex justify-end">
            <Button
              onClick={handleNextQuestion}
              disabled={selectedOptionIndex === null}
              variant="primary"
              className="px-8 py-3"
            >
              {currentQuestionIndex === questions.length - 1 ? 'Submit Quiz' : 'Next Question'}
            </Button>
          </div>
        </div>
      )}

      {quizCompleted && (
        <div className="bg-white p-8 rounded-lg shadow-lg max-w-4xl mx-auto border border-blue-100">
          <h2 className="text-3xl font-bold text-blue-800 text-center mb-6">Quiz Results</h2>
          <p className="text-xl text-gray-700 text-center mb-8">
            You scored <span className="font-extrabold text-blue-700">{score}</span> out of <span className="font-extrabold text-blue-700">{questions.length}</span>!
          </p>

          <div className="space-y-6">
            {questions.map((q, index) => (
              <div key={index} className="border border-gray-200 rounded-lg p-5 bg-gray-50">
                <p className="font-bold text-lg text-gray-800 mb-3">
                  Q{index + 1}: {q.question}
                </p>
                <ul className="space-y-2">
                  {q.options.map((option, optIndex) => (
                    <li
                      key={optIndex}
                      className={`p-2 rounded-md transition-colors duration-150
                        ${optIndex === q.correctAnswerIndex
                          ? 'bg-green-100 text-green-800 font-semibold' // Correct answer
                          : userSelectedAnswers[index] === optIndex
                            ? 'bg-red-100 text-red-800 font-semibold' // User's incorrect answer
                            : 'text-gray-700' // Other options
                        }`}
                    >
                      <span className="font-semibold mr-2">{String.fromCharCode(65 + optIndex)}.</span> {option}
                      {optIndex === q.correctAnswerIndex && (
                        <span className="ml-2 text-green-600">
                          {userSelectedAnswers[index] === optIndex ? ' (Your Answer, Correct!)' : ' (Correct Answer)'}
                        </span>
                      )}
                      {userSelectedAnswers[index] === optIndex && optIndex !== q.correctAnswerIndex && (
                        <span className="ml-2 text-red-600"> (Your Answer, Incorrect)</span>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="text-center mt-10">
            <Button onClick={handleRestartQuiz} variant="primary" className="text-lg px-8 py-3">
              Start New Quiz
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default QuizPage;