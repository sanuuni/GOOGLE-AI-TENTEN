
import React, { useState } from 'react';
import Button from '../components/Button';

const RegistrationPage: React.FC = () => {
  // Registration Form State
  const [formData, setFormData] = useState({
    studentName: '',
    enrolmentDate: '',
    address: '',
    city: '',
    province: '',
    postCode: '',
    homePhone: '',
    cellPhone: '',
    licenseNo: '',
    dob: '',
    licenseClass: '',
    expDate: '',
    issueDate: '',
    cond: '',
    email: '',
    parentName: '',
    parentPhone: '',
    pkgA: false,
    pkgB: false,
    pkgC: false,
    pkgD: false,
    pkgE: false,
    feeRental: false,
    feeCert: false,
    note1: '',
    note2: '',
    note3: '',
    note4: '',
    studentSig: '',
    studentSigDate: '',
    parentSig: '',
    parentSigDate: '',
    repSig: '',
    repSigDate: '',
  });

  // Evaluation Form State (D.R.I.V.E.R.)
  const [evalData, setEvalData] = useState({
    schoolName: 'Ten Ten Driving School',
    studentName: '',
    genderMale: false,
    genderFemale: false,
    address: '',
    pickHome: false,
    pickOther: false,
    city: '',
    prov: '',
    postal: '',
    homePhone: '',
    cellPhone: '',
    officePhone: '403-404-1010',
    fax: '',
    operatorNo: '',
    dob: '',
    cond: '',
    class7: false,
    class5GDL: false,
    class5: false,
    otherClass: false,
    issueDate: '',
    expiryDate: '',
    regDate: '',
    checkClass7: false,
    checkClass5: false,
    checkOther: false,
    checkAuto: false,
    checkManual: false,
    totalHours: '',
    finalGrade: '',
    certNumber: '',
    issueDateCert: '',
    rating: '',
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData(prev => ({ ...prev, [name]: checked }));
  };

  const handleEvalChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setEvalData(prev => ({ ...prev, [name]: value }));
  };

  const handleEvalCheckbox = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setEvalData(prev => ({ ...prev, [name]: checked }));
  };

  const copyRegistrationInfo = () => {
    setEvalData(prev => ({
      ...prev,
      studentName: formData.studentName,
      address: formData.address,
      city: formData.city,
      prov: formData.province,
      postal: formData.postCode,
      homePhone: formData.homePhone,
      cellPhone: formData.cellPhone,
      operatorNo: formData.licenseNo,
      dob: formData.dob,
      cond: formData.cond,
      issueDate: formData.issueDate,
      expiryDate: formData.expDate,
    }));
  };

  const handlePrint = () => {
    window.print();
  };

  const handleEmailSubmit = () => {
    // Construct the email body
    const body = `
NEW STUDENT REGISTRATION

--- STUDENT INFO ---
Name: ${formData.studentName}
Enrolment Date: ${formData.enrolmentDate}
Address: ${formData.address}
City: ${formData.city}, Prov: ${formData.province}, PC: ${formData.postCode}
Home Phone: ${formData.homePhone}
Cell Phone: ${formData.cellPhone}
Email: ${formData.email}

--- LICENSE INFO ---
License No: ${formData.licenseNo}
DOB: ${formData.dob}
Class: ${formData.licenseClass}
Exp Date: ${formData.expDate}
Issue Date: ${formData.issueDate}
Cond: ${formData.cond}

--- PARENT/GUARDIAN ---
Name: ${formData.parentName}
Phone: ${formData.parentPhone}

--- SELECTED PACKAGES ---
${formData.pkgA ? '[x] Package A ($729 + GST)' : '[ ] Package A'}
${formData.pkgB ? '[x] Package B ($625 + GST)' : '[ ] Package B'}
${formData.pkgC ? '[x] Package C ($385 + GST)' : '[ ] Package C'}
${formData.pkgD ? '[x] Package D ($1354 + GST)' : '[ ] Package D'}
${formData.pkgE ? '[x] Package E ($130 + GST)' : '[ ] Package E'}

--- OTHER FEES ---
${formData.feeRental ? '[x] Car Rental ($80 + GST)' : '[ ] Car Rental'}
${formData.feeCert ? '[x] Cert Re-issue ($50 + GST)' : '[ ] Cert Re-issue'}

--- NOTES ---
1. ${formData.note1}
2. ${formData.note2}
3. ${formData.note3}
4. ${formData.note4}

--- SIGNATURES ---
Student: ${formData.studentSig} (Date: ${formData.studentSigDate})
Parent: ${formData.parentSig} (Date: ${formData.parentSigDate})
Rep: ${formData.repSig} (Date: ${formData.repSigDate})
    `;

    // Encode for URL
    const subject = encodeURIComponent(`New Registration: ${formData.studentName}`);
    const encodedBody = encodeURIComponent(body);
    
    // Open mail client
    window.location.href = `mailto:sankatenten@gmail.com?subject=${subject}&body=${encodedBody}`;
  };

  const inputClass = "w-full border-b border-gray-400 h-8 focus:outline-none focus:border-blue-600 bg-transparent print:border-b print:border-gray-400 text-gray-800";
  const checkboxClass = "w-5 h-5 border-2 border-gray-400 mr-2 flex-shrink-0 accent-blue-700 cursor-pointer rounded-sm focus:ring-2 focus:ring-blue-500";
  
  // Evaluation form specific classes
  const evalInputClass = "w-full bg-transparent focus:outline-none text-sm text-center font-mono";
  const cellClass = "border border-gray-400 p-1 h-8 align-middle";
  const labelClass = "text-xs font-bold uppercase text-gray-700";

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl print:max-w-none print:px-0">
      <div className="flex flex-col md:flex-row justify-between mb-4 print:hidden gap-4">
        <Button onClick={handleEmailSubmit} className="flex-1 bg-green-600 hover:bg-green-700 text-white">
          <svg className="w-5 h-5 mr-2 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
          </svg>
          Submit Registration via Email
        </Button>
        <Button onClick={handlePrint} variant="secondary" className="flex-1 bg-blue-600 text-white hover:bg-blue-700 border-none">
          <svg className="w-5 h-5 mr-2 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24">
             <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
          </svg>
          Save as PDF / Print
        </Button>
      </div>
      <p className="text-center text-sm text-gray-600 mb-6 print:hidden italic">
        Tip: To save as a PDF, click "Save as PDF / Print" and select <strong>"Save as PDF"</strong> in the destination box.
      </p>

      {/* ======================= REGISTRATION FORM ======================= */}
      <div className="bg-white p-8 md:p-12 shadow-xl border border-gray-200 print:shadow-none print:border-none print:p-0 mb-10" id="registration-form">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold uppercase tracking-wide">Ten Ten Driving School LTD</h1>
          <p className="text-gray-700">4641-128 Ave NE,</p>
          <p className="text-gray-700">Calgary, AB T3N 1T5</p>
          <p className="text-gray-700 font-semibold">403-404-1010 sankatenten@gmail.com</p>
          <h2 className="text-xl font-bold mt-6 uppercase underline">Student Registration and Agreement</h2>
        </div>

        {/* Form Fields */}
        <div className="space-y-4 mb-8 text-sm md:text-base">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <label className="font-semibold block mb-1">Student Name:</label>
              <input name="studentName" value={formData.studentName} onChange={handleInputChange} type="text" className={inputClass} />
            </div>
            <div className="w-full md:w-1/3">
              <label className="font-semibold block mb-1">Enrolment Date:</label>
              <input name="enrolmentDate" value={formData.enrolmentDate} onChange={handleInputChange} type="date" className={inputClass} />
            </div>
          </div>

          <div>
            <label className="font-semibold block mb-1">Address:</label>
            <input name="address" value={formData.address} onChange={handleInputChange} type="text" className={inputClass} />
          </div>

          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <label className="font-semibold block mb-1">City:</label>
              <input name="city" value={formData.city} onChange={handleInputChange} type="text" className={inputClass} />
            </div>
            <div className="flex-1">
              <label className="font-semibold block mb-1">Province:</label>
              <input name="province" value={formData.province} onChange={handleInputChange} type="text" className={inputClass} />
            </div>
            <div className="flex-1">
              <label className="font-semibold block mb-1">Post code:</label>
              <input name="postCode" value={formData.postCode} onChange={handleInputChange} type="text" className={inputClass} />
            </div>
          </div>

          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <label className="font-semibold block mb-1">Home Phone:</label>
              <input name="homePhone" value={formData.homePhone} onChange={handleInputChange} type="tel" className={inputClass} />
            </div>
            <div className="flex-1">
              <label className="font-semibold block mb-1">Cell Phone:</label>
              <input name="cellPhone" value={formData.cellPhone} onChange={handleInputChange} type="tel" className={inputClass} />
            </div>
          </div>

          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <label className="font-semibold block mb-1">License/Permit No:</label>
              <input name="licenseNo" value={formData.licenseNo} onChange={handleInputChange} type="text" className={inputClass} />
            </div>
            <div className="flex-1">
              <label className="font-semibold block mb-1">Date of Birth:</label>
              <input name="dob" value={formData.dob} onChange={handleInputChange} type="date" className={inputClass} />
            </div>
          </div>

          <div className="flex flex-wrap gap-4">
            <div className="w-20">
              <label className="font-semibold block mb-1">Class:</label>
              <input name="licenseClass" value={formData.licenseClass} onChange={handleInputChange} type="text" className={inputClass} />
            </div>
            <div className="flex-1">
              <label className="font-semibold block mb-1">Exp Date:</label>
              <input name="expDate" value={formData.expDate} onChange={handleInputChange} type="date" className={inputClass} />
            </div>
            <div className="flex-1">
              <label className="font-semibold block mb-1">Issue Date:</label>
              <input name="issueDate" value={formData.issueDate} onChange={handleInputChange} type="date" className={inputClass} />
            </div>
            <div className="flex-1">
              <label className="font-semibold block mb-1">Cond:</label>
              <input name="cond" value={formData.cond} onChange={handleInputChange} type="text" className={inputClass} />
            </div>
          </div>

          <div>
            <label className="font-semibold block mb-1">Email:</label>
            <input name="email" value={formData.email} onChange={handleInputChange} type="email" className={inputClass} />
          </div>

          <div className="mt-4">
            <p className="font-bold underline mb-2">Parent/Guardian</p>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <label className="font-semibold block mb-1">Name:</label>
                <input name="parentName" value={formData.parentName} onChange={handleInputChange} type="text" className={inputClass} />
              </div>
              <div className="flex-1">
                <label className="font-semibold block mb-1">Phone#:</label>
                <input name="parentPhone" value={formData.parentPhone} onChange={handleInputChange} type="tel" className={inputClass} />
              </div>
            </div>
          </div>
        </div>

        {/* Certificate Courses Section */}
        <div className="mb-8">
          <div className="border-2 border-black p-4 text-center font-bold mb-4">
            <p>CERTIFICATE COURSES</p>
            <p className="font-normal">(Training hours and performance must meet standards for certificate eligibility)</p>
          </div>
          
          <h3 className="font-bold mb-2">Courses eligible for insurance reduction FEE and driving courses</h3>
          <div className="space-y-2 ml-2">
            <label className="flex items-center cursor-pointer hover:bg-gray-50 p-1 rounded">
              <input name="pkgA" checked={formData.pkgA} onChange={handleCheckboxChange} type="checkbox" className={checkboxClass} />
              <span>Package "A" (10 hrs. in-vehicle, 15 hrs. in-class) <span className="font-semibold">$729.00 + GST</span></span>
            </label>
            <label className="flex items-center cursor-pointer hover:bg-gray-50 p-1 rounded">
              <input name="pkgB" checked={formData.pkgB} onChange={handleCheckboxChange} type="checkbox" className={checkboxClass} />
              <span>Package "B" (10 hrs. in-vehicle) <span className="font-semibold">$625.00 + GST</span></span>
            </label>
            <label className="flex items-center cursor-pointer hover:bg-gray-50 p-1 rounded">
              <input name="pkgC" checked={formData.pkgC} onChange={handleCheckboxChange} type="checkbox" className={checkboxClass} />
              <span>Package "C" (6 hrs. in-vehicle) <span className="font-semibold">$385.00 + GST</span></span>
            </label>
            <label className="flex items-center cursor-pointer hover:bg-gray-50 p-1 rounded">
              <input name="pkgD" checked={formData.pkgD} onChange={handleCheckboxChange} type="checkbox" className={checkboxClass} />
              <span>Package "D" (20 hrs. in-vehicle, 15 hrs. in-class) <span className="font-semibold">$1354.00 + GST</span></span>
            </label>
            <label className="flex items-center cursor-pointer hover:bg-gray-50 p-1 rounded">
              <input name="pkgE" checked={formData.pkgE} onChange={handleCheckboxChange} type="checkbox" className={checkboxClass} />
              <span>Package "E" (2 hrs. in-vehicle) <span className="font-semibold">$130.00 + GST</span></span>
            </label>
          </div>
        </div>

        {/* Other Fees Section */}
        <div className="mb-8">
          <h3 className="font-bold mb-2 uppercase">Other Fees</h3>
          <div className="space-y-2 ml-2">
            <label className="flex items-center cursor-pointer hover:bg-gray-50 p-1 rounded">
              <input name="feeRental" checked={formData.feeRental} onChange={handleCheckboxChange} type="checkbox" className={checkboxClass} />
              <span>Car rental for basic road test <span className="font-semibold">$80 + GST</span></span>
            </label>
            <label className="flex items-center cursor-pointer hover:bg-gray-50 p-1 rounded">
              <input name="feeCert" checked={formData.feeCert} onChange={handleCheckboxChange} type="checkbox" className={checkboxClass} />
              <span>Course Completion Certificate re-issue: <span className="font-semibold">$50 + GST</span></span>
            </label>
            <div className="flex items-start p-1">
               <div className="w-6 h-6 border-2 border-gray-400 mr-2 mt-1 flex-shrink-0 bg-gray-200"></div>
               <p className="font-semibold">Cancellation of lessons must be made at least 24 hours in advance, otherwise, a $55.00 cancellation fee will be charged.</p>
            </div>
          </div>
        </div>

        {/* Notes Section */}
        <div className="mb-8">
          <p className="font-bold mb-2">Note</p>
          <div className="space-y-4">
            <div className="flex items-center">
              <span className="mr-2 font-bold">1.</span>
              <input name="note1" value={formData.note1} onChange={handleInputChange} type="text" className={inputClass} />
            </div>
            <div className="flex items-center">
              <span className="mr-2 font-bold">2.</span>
              <input name="note2" value={formData.note2} onChange={handleInputChange} type="text" className={inputClass} />
            </div>
            <div className="flex items-center">
              <span className="mr-2 font-bold">3.</span>
              <input name="note3" value={formData.note3} onChange={handleInputChange} type="text" className={inputClass} />
            </div>
            <div className="flex items-center">
              <span className="mr-2 font-bold">4.</span>
              <input name="note4" value={formData.note4} onChange={handleInputChange} type="text" className={inputClass} />
            </div>
          </div>
        </div>
        
        {/* Responsibilities Section */}
        <div className="mt-8">
           <div className="mb-8">
             <h3 className="font-bold text-center text-lg uppercase mb-2">RESPONSIBILITIES OF TEN TEN DRIVING SCHOOL (“THE SCHOOL”)</h3>
             <div className="text-center mb-4 text-sm text-gray-600">
               <p>4641-128 Ave NE, Calgary, AB T3N 1T5</p>
               <p>403-404-1010 sankatenten@gmail.com</p>
             </div>
             <ol className="list-decimal list-outside ml-5 space-y-2 text-sm text-justify">
               <li>The school will provide training in a timely and professional manner.</li>
               <li>The Driver Training vehicle will be clean and in good running condition. The vehicle will have a valid license plate, registration and insurance.</li>
               <li>Your driving instructor is licensed by Alberta Transportation and will produce his or her instructor’s license and operator’s license upon request.</li>
               <li>If the school has to cancel a lesson due to instructor illness, vehicle breakdown, etc., every effort will be made to accommodate the student and to reschedule the lesson.</li>
               <li>The driving instructor will give full attention to the student during the in-vehicle lesson. The instructor’s cell phone will be off and may not be used unless the vehicle is safely stopped and the student gives permission.</li>
               <li>An in-vehicle report card/student summary with a detailed evaluation will be completed by the instructor and explained at the completion of each lesson.</li>
               <li>Driver Training vehicle has dash cam evidence to help prove of car accident claim.</li>
             </ol>
           </div>

           <div className="mb-8">
             <h3 className="font-bold text-center text-lg uppercase mb-4">RESPONSIBILITIES OF THE STUDENT</h3>
             <ol className="list-decimal list-outside ml-5 space-y-2 text-sm text-justify">
               <li>The student must possess, at minimum, a class 7 Alberta license and have the license in their possession during all in-vehicle training.</li>
               <li>A student who attends a course that offers a <strong>Driver Education Course Completion Certificate</strong> must have the required minimum hours of training for the specific course and must pass the applicable examination/performance evaluation before they can receive the certificate.</li>
               <li>Any acts of negligence on the Student’s part that result in damages or fines will be the responsibility of the student.</li>
               <li>Learning to drive must be taken seriously. Students are expected to give best efforts during classroom and in-vehicle lessons. Unacceptable behavior (drinking, drugs, swearing, continually being late, etc.) will not be tolerated and the school may discontinue the lesson at the student’s expense.</li>
               <li>During a Driver Training lesson, in-classroom or in-vehicle, all electronic communication devices (e.g., cell phones) are not to be used by the student.</li>
               <li className="bg-yellow-300 font-bold p-1 rounded" style={{ printColorAdjust: 'exact', WebkitPrintColorAdjust: 'exact' }}>Cancellation of lessons must be made at least 24 hours in advance, otherwise, a $55.00 cancellation fee will be charged.</li>
               <li>The School may waive the fee if, in its sole discretion, it determines the circumstances merit doing so.</li>
               <li className="bg-yellow-300 font-bold p-1 rounded" style={{ printColorAdjust: 'exact', WebkitPrintColorAdjust: 'exact' }}>All training must be completed within 4 months from enrolment date.</li>
             </ol>
           </div>

           {/* Agreement Signature */}
           <div className="mt-8 border-t-2 border-gray-300 pt-6">
             <p className="font-bold mb-6">I have thoroughly reviewed this document and agree to accept and abide by the rules contained herein</p>
             
             <div className="space-y-6">
               <div className="flex flex-col md:flex-row gap-4 items-end">
                 <div className="flex-1 w-full">
                   <label className="font-semibold block mb-1">Student signature:</label>
                   <input name="studentSig" value={formData.studentSig} onChange={handleInputChange} type="text" className={inputClass} placeholder="(Type name to sign)" />
                 </div>
                 <div className="w-full md:w-1/3">
                   <label className="font-semibold block mb-1">Date:</label>
                   <input name="studentSigDate" value={formData.studentSigDate} onChange={handleInputChange} type="date" className={inputClass} />
                 </div>
               </div>

               <div className="flex flex-col md:flex-row gap-4 items-end">
                 <div className="flex-1 w-full">
                   <label className="font-semibold block mb-1">Parent/Guardian signature:</label>
                   <input name="parentSig" value={formData.parentSig} onChange={handleInputChange} type="text" className={inputClass} placeholder="(Type name to sign)" />
                 </div>
                 <div className="w-full md:w-1/3">
                   <label className="font-semibold block mb-1">Date:</label>
                   <input name="parentSigDate" value={formData.parentSigDate} onChange={handleInputChange} type="date" className={inputClass} />
                 </div>
               </div>

               <div className="flex flex-col md:flex-row gap-4 items-end">
                 <div className="flex-1 w-full">
                   <label className="font-semibold block mb-1">School Representative:</label>
                   <input name="repSig" value={formData.repSig} onChange={handleInputChange} type="text" className={inputClass} />
                 </div>
                 <div className="w-full md:w-1/3">
                   <label className="font-semibold block mb-1">Date:</label>
                   <input name="repSigDate" value={formData.repSigDate} onChange={handleInputChange} type="date" className={inputClass} />
                 </div>
               </div>
             </div>
           </div>
        </div>
      </div>

      {/* ======================= DRIVER EVALUATION REPORT (P1) ======================= */}
      <div className="break-before-page bg-white p-8 md:p-12 shadow-xl border border-gray-200 print:shadow-none print:border-none print:p-0 mb-10 text-xs md:text-sm">
         {/* Helper Button */}
         <div className="mb-4 print:hidden flex justify-end">
            <button onClick={copyRegistrationInfo} className="bg-gray-200 hover:bg-gray-300 text-gray-800 text-xs px-3 py-1 rounded">
                Copy from Registration
            </button>
         </div>

         <div className="flex justify-between items-center mb-4 border-b pb-2">
            <h1 className="text-xl font-serif font-bold italic">Alberta <span className="text-xs font-sans font-normal">Government</span></h1>
            <div className="text-right">
                <h2 className="text-lg font-bold">Driving In-Vehicle Evaluation Report</h2>
                <h3 className="text-md font-bold">(D.R.I.V.E.R.)</h3>
            </div>
         </div>

         {/* Header Info Grid */}
         <div className="grid grid-cols-2 gap-0 border border-black mb-4">
             {/* Left Col */}
             <div className="border-r border-black p-1">
                 <div className="flex border-b border-gray-300 mb-1">
                    <label className={labelClass}>Student Name:</label>
                    <input name="studentName" value={evalData.studentName} onChange={handleEvalChange} className="flex-1 ml-2 bg-transparent focus:outline-none" />
                 </div>
                 <div className="flex justify-end gap-2 text-xs mb-1">
                    <label><input type="checkbox" name="genderMale" checked={evalData.genderMale} onChange={handleEvalCheckbox} /> Male</label>
                    <label><input type="checkbox" name="genderFemale" checked={evalData.genderFemale} onChange={handleEvalCheckbox} /> Female</label>
                 </div>
                 <div className="flex border-b border-gray-300 mb-1">
                    <label className={labelClass}>Address:</label>
                    <input name="address" value={evalData.address} onChange={handleEvalChange} className="flex-1 ml-2 bg-transparent focus:outline-none" />
                 </div>
                 <div className="flex gap-2 text-xs mb-1">
                    <span className="font-bold">Pick Up At:</span>
                    <label><input type="checkbox" name="pickHome" checked={evalData.pickHome} onChange={handleEvalCheckbox} /> Home</label>
                    <label><input type="checkbox" name="pickOther" checked={evalData.pickOther} onChange={handleEvalCheckbox} /> Other</label>
                 </div>
                 <div className="flex gap-2 mb-1">
                    <div className="flex-1 border-b border-gray-300">
                        <label className={labelClass}>City/Town:</label>
                        <input name="city" value={evalData.city} onChange={handleEvalChange} className="ml-1 w-20 bg-transparent focus:outline-none" />
                    </div>
                    <div className="flex-1 border-b border-gray-300">
                        <label className={labelClass}>Prov:</label>
                        <input name="prov" value={evalData.prov} onChange={handleEvalChange} className="ml-1 w-10 bg-transparent focus:outline-none" />
                    </div>
                    <div className="flex-1 border-b border-gray-300">
                        <label className={labelClass}>Postal:</label>
                        <input name="postal" value={evalData.postal} onChange={handleEvalChange} className="ml-1 w-16 bg-transparent focus:outline-none" />
                    </div>
                 </div>
                 <div className="flex gap-2">
                    <div className="flex-1 border-b border-gray-300">
                        <label className={labelClass}>Home Phone:</label>
                        <input name="homePhone" value={evalData.homePhone} onChange={handleEvalChange} className="ml-1 w-full bg-transparent focus:outline-none" />
                    </div>
                    <div className="flex-1 border-b border-gray-300">
                        <label className={labelClass}>Cell:</label>
                        <input name="cellPhone" value={evalData.cellPhone} onChange={handleEvalChange} className="ml-1 w-full bg-transparent focus:outline-none" />
                    </div>
                 </div>
             </div>

             {/* Right Col */}
             <div className="p-1">
                 <div className="flex border-b border-gray-300 mb-1">
                    <label className={labelClass}>Name of Driving School:</label>
                    <input name="schoolName" value={evalData.schoolName} onChange={handleEvalChange} className="flex-1 ml-2 bg-transparent focus:outline-none font-bold" />
                 </div>
                 <div className="flex border-b border-gray-300 mb-1">
                    <label className={labelClass}>Address:</label>
                    <div className="flex-1 ml-2 text-xs">4641-128 Ave NE</div>
                 </div>
                 <div className="flex gap-2 mb-1">
                    <div className="flex-1 border-b border-gray-300">
                        <label className={labelClass}>City/Town:</label>
                        <div className="ml-1 w-full text-xs">Calgary</div>
                    </div>
                    <div className="flex-1 border-b border-gray-300">
                        <label className={labelClass}>Prov:</label>
                        <div className="ml-1 w-full text-xs">AB</div>
                    </div>
                    <div className="flex-1 border-b border-gray-300">
                        <label className={labelClass}>Postal:</label>
                        <div className="ml-1 w-full text-xs">T3N 1T5</div>
                    </div>
                 </div>
                 <div className="flex gap-2">
                    <div className="flex-1 border-b border-gray-300">
                        <label className={labelClass}>Office Phone:</label>
                        <input name="officePhone" value={evalData.officePhone} onChange={handleEvalChange} className="ml-1 w-full bg-transparent focus:outline-none" />
                    </div>
                    <div className="flex-1 border-b border-gray-300">
                        <label className={labelClass}>Fax:</label>
                        <input name="fax" value={evalData.fax} onChange={handleEvalChange} className="ml-1 w-full bg-transparent focus:outline-none" />
                    </div>
                 </div>
             </div>
         </div>

         {/* Licence Info */}
         <div className="bg-yellow-100 border border-black p-1 mb-4 flex flex-wrap gap-2 text-xs" style={{ printColorAdjust: 'exact', WebkitPrintColorAdjust: 'exact' }}>
            <div className="bg-black text-white px-2 py-1 font-bold">Student/Client Licence Information</div>
            <div className="flex-1 flex gap-1 items-center">
                <label>Operator's Licence Number</label>
                <input name="operatorNo" value={evalData.operatorNo} onChange={handleEvalChange} className="border-b border-gray-500 bg-transparent flex-1" />
            </div>
            <div className="flex-1 flex gap-1 items-center">
                <label>Date of Birth</label>
                <input name="dob" value={evalData.dob} onChange={handleEvalChange} type="date" className="border-b border-gray-500 bg-transparent flex-1" />
            </div>
            <div className="flex-1 flex gap-1 items-center">
                <label>Condition Code</label>
                <input name="cond" value={evalData.cond} onChange={handleEvalChange} className="border-b border-gray-500 bg-transparent w-10" />
            </div>
         </div>
         <div className="flex gap-4 text-xs mb-4 border-b border-black pb-1">
             <label><input type="checkbox" name="class7" checked={evalData.class7} onChange={handleEvalCheckbox} /> Class 7</label>
             <label><input type="checkbox" name="class5GDL" checked={evalData.class5GDL} onChange={handleEvalCheckbox} /> Class 5 - GDL</label>
             <label><input type="checkbox" name="class5" checked={evalData.class5} onChange={handleEvalCheckbox} /> Class 5</label>
             <label><input type="checkbox" name="otherClass" checked={evalData.otherClass} onChange={handleEvalCheckbox} /> Other</label>
             <div className="ml-auto flex gap-2">
                <label>Issue Date: <input type="date" name="issueDate" value={evalData.issueDate} onChange={handleEvalChange} className="border-b border-black" /></label>
                <label>Expiry Date: <input type="date" name="expiryDate" value={evalData.expiryDate} onChange={handleEvalChange} className="border-b border-black" /></label>
             </div>
         </div>

         <div className="grid grid-cols-2 gap-4">
             {/* Left Column: In-Vehicle Log */}
             <div className="border border-black bg-gray-100 p-2" style={{ printColorAdjust: 'exact', WebkitPrintColorAdjust: 'exact' }}>
                 <h3 className="font-bold border-b border-black mb-2">In-Vehicle <span className="font-normal float-right">Name of Instructor</span></h3>
                 <div className="space-y-1">
                     {[...Array(10)].map((_, i) => (
                         <div key={i} className="mb-2">
                            <div className="flex items-center text-xs">
                                <span className="font-bold mr-1">{i+1}. Date</span>
                                <input className="w-20 border-b border-gray-400 bg-transparent" />
                                <span className="mx-1">Time</span>
                                <input className="w-12 border-b border-gray-400 bg-transparent" />
                                <span className="mx-1 font-bold">-</span>
                                <input className="w-12 border-b border-gray-400 bg-transparent" />
                            </div>
                            <div className="flex items-center text-xs ml-4">
                                <span className="font-bold mr-1">Initials:</span>
                                <span>Instructor</span>
                                <input className="w-16 border-b border-gray-400 bg-transparent mx-1" />
                                <span>Student</span>
                                <input className="w-16 border-b border-gray-400 bg-transparent mx-1" />
                            </div>
                         </div>
                     ))}
                 </div>
                 <div className="flex justify-between font-bold mt-2 pt-2 border-t border-black">
                    <span>Total Hours <input name="totalHours" value={evalData.totalHours} onChange={handleEvalChange} className="w-16 border-b border-black bg-transparent" /></span>
                    <span>Final Grade <input name="finalGrade" value={evalData.finalGrade} onChange={handleEvalChange} className="w-16 border-b border-black bg-transparent" /></span>
                 </div>
             </div>

             {/* Right Column: General Info & Classroom */}
             <div>
                <div className="bg-black text-white p-1 font-bold mb-2">General Information</div>
                <div className="text-xs mb-2">
                    <label>Course Registration Date (yyyy-mm-dd): <input name="regDate" value={evalData.regDate} onChange={handleEvalChange} className="border-b border-black bg-transparent" /></label>
                </div>
                <div className="text-xs space-y-1 mb-4">
                    <p className="font-bold">Check appropriate box(es)</p>
                    <label className="block"><input type="checkbox" name="checkClass7" checked={evalData.checkClass7} onChange={handleEvalCheckbox} /> Class 7 and 5-GDL (requires a minimum of 15 hours classroom and 10 hours in-vehicle.)</label>
                    <label className="block"><input type="checkbox" name="checkClass5" checked={evalData.checkClass5} onChange={handleEvalCheckbox} /> Class 5 non-GDL (requires a minimum of 15 hours classroom and 6 hours in-vehicle.)</label>
                    <label className="block"><input type="checkbox" name="checkOther" checked={evalData.checkOther} onChange={handleEvalCheckbox} /> Other</label>
                    <div className="flex gap-4 mt-1">
                        <label><input type="checkbox" name="checkAuto" checked={evalData.checkAuto} onChange={handleEvalCheckbox} /> Automatic</label>
                        <label><input type="checkbox" name="checkManual" checked={evalData.checkManual} onChange={handleEvalCheckbox} /> Manual Shift</label>
                    </div>
                </div>

                <div className="border border-black bg-gray-100 p-2 mb-4" style={{ printColorAdjust: 'exact', WebkitPrintColorAdjust: 'exact' }}>
                     <h3 className="font-bold border-b border-black mb-2">Classroom <span className="font-normal float-right">Name of Instructor</span></h3>
                     <div className="space-y-1">
                         {[...Array(6)].map((_, i) => (
                             <div key={i} className="flex items-center text-xs mb-1">
                                <span className="font-bold mr-1 w-8">{i+1}. Date</span>
                                <input className="flex-1 border-b border-gray-400 bg-transparent" />
                                <span className="mx-1">Time</span>
                                <input className="w-10 border-b border-gray-400 bg-transparent" />
                                <span className="mx-1 font-bold">-</span>
                                <input className="w-10 border-b border-gray-400 bg-transparent" />
                            </div>
                         ))}
                     </div>
                     <div className="flex justify-between font-bold mt-2 pt-2 border-t border-black text-xs">
                        <span>Total Hours <input className="w-16 border-b border-black bg-transparent" /></span>
                        <span>Final Grade <input className="w-16 border-b border-black bg-transparent" /></span>
                     </div>
                </div>

                <div className="bg-black text-white p-1 font-bold mb-1 text-xs">Course Completion Certificate</div>
                <div className="flex text-xs mb-2">
                    <span className="mr-2">Number</span>
                    <input name="certNumber" value={evalData.certNumber} onChange={handleEvalChange} className="border-b border-black bg-transparent w-20" />
                    <span className="ml-auto mr-2">Issue Date</span>
                    <input name="issueDateCert" value={evalData.issueDateCert} onChange={handleEvalChange} className="border-b border-black bg-transparent w-24" />
                </div>
                <div className="text-xs space-y-1 mb-2">
                    <p><strong>A</strong> (8.0-9.0) - Student exceeds the requirements.</p>
                    <p><strong>B</strong> 7.5 - Student meets the requirements.</p>
                    <p><strong>C</strong> (6.0-7.0) - Suggest student obtain additional practice with a fully licenced driver.</p>
                    <p><strong>D</strong> (4.0-5.0) - Suggest student obtain additional professional driver education.</p>
                </div>
                <div className="border border-black p-2 flex items-center justify-between">
                    <span className="font-bold">Overall Rating for Driver Education course:</span>
                    <input name="rating" value={evalData.rating} onChange={handleEvalChange} className="border border-black w-16 h-8 text-center font-bold text-lg" />
                </div>
             </div>
         </div>
      </div>

      {/* ======================= DRIVER EVALUATION REPORT (P3 - Skills) ======================= */}
      <div className="break-before-page bg-white p-8 md:p-12 shadow-xl border border-gray-200 print:shadow-none print:border-none print:p-0 mb-10 text-xs">
        <div className="flex justify-between mb-4">
            <div>Student Name: <input className="border-b border-black w-64" value={evalData.studentName} readOnly /></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Left: Overall Skills */}
            <div className="border border-black">
                 {/* Header Row */}
                 <div className="grid grid-cols-[3fr_repeat(5,1fr)] bg-gray-200 border-b border-black" style={{ printColorAdjust: 'exact', WebkitPrintColorAdjust: 'exact' }}>
                     <div className="p-1 font-bold text-center border-r border-black flex items-center justify-center">Overall Skills</div>
                     <div className="text-center">
                         <div className="border-b border-black p-1 font-bold">Hours</div>
                         <div className="grid grid-cols-5 text-center">
                             {[2,4,6,8,10].map(h => <div key={h} className="border-r border-black last:border-none p-1">{h}</div>)}
                         </div>
                     </div>
                 </div>

                 {/* Skills Content */}
                 <div className="bg-gray-100 border-b border-black p-1 font-bold text-center">Vehicle-Handling (Psychomotor) Skills</div>
                 {[
                     "Steering", "Braking", "Speed Control"
                 ].map(skill => (
                     <div key={skill} className="grid grid-cols-[3fr_repeat(5,1fr)] border-b border-gray-400">
                         <div className="p-1 border-r border-black">{skill}</div>
                         <div className="grid grid-cols-5">
                             {[...Array(5)].map((_, i) => <div key={i} className="border-r border-black last:border-none p-0"><input className={evalInputClass} /></div>)}
                         </div>
                     </div>
                 ))}
                 
                 <div className="grid grid-cols-[3fr_repeat(5,1fr)] border-b border-gray-400">
                     <div className="grid grid-rows-3 border-r border-black">
                         <div className="p-1 font-bold row-span-3 flex items-center">Scanning (Space)</div>
                     </div>
                     <div className="col-span-1 grid grid-cols-5">
                        {/* This part is tricky with nested grids, simplifying visual structure */}
                         <div className="col-span-5 grid grid-rows-3">
                             <div className="grid grid-cols-[1fr_repeat(5,1fr)] border-b border-gray-300">
                                 <div className="p-1 text-xs">Rear</div>
                                 <input className={evalInputClass} /><input className={evalInputClass} /><input className={evalInputClass} /><input className={evalInputClass} /><input className={evalInputClass} />
                             </div>
                             <div className="grid grid-cols-[1fr_repeat(5,1fr)] border-b border-gray-300">
                                 <div className="p-1 text-xs">Peripheral</div>
                                 <input className={evalInputClass} /><input className={evalInputClass} /><input className={evalInputClass} /><input className={evalInputClass} /><input className={evalInputClass} />
                             </div>
                             <div className="grid grid-cols-[1fr_repeat(5,1fr)]">
                                 <div className="p-1 text-xs">Front</div>
                                 <input className={evalInputClass} /><input className={evalInputClass} /><input className={evalInputClass} /><input className={evalInputClass} /><input className={evalInputClass} />
                             </div>
                         </div>
                     </div>
                 </div>
                 
                 <div className="grid grid-cols-[3fr_repeat(5,1fr)] border-b border-gray-400">
                     <div className="grid grid-rows-3 border-r border-black p-1 font-bold flex items-center">Visual Skills</div>
                     <div className="col-span-1 col-start-2 -ml-[100%] w-full pl-[33%]"> {/* Hacky grid alignment or just list */}
                        <div className="grid grid-cols-[2fr_repeat(5,1fr)] border-b border-gray-300">
                            <div className="p-1 text-xs border-r border-black">Tracking</div>
                             {[...Array(5)].map((_, i) => <input key={i} className="border-r border-black last:border-none text-center w-full" />)}
                        </div>
                        <div className="grid grid-cols-[2fr_repeat(5,1fr)] border-b border-gray-300">
                            <div className="p-1 text-xs border-r border-black">Intersections</div>
                             {[...Array(5)].map((_, i) => <input key={i} className="border-r border-black last:border-none text-center w-full" />)}
                        </div>
                        <div className="grid grid-cols-[2fr_repeat(5,1fr)] border-b border-gray-300">
                            <div className="p-1 text-xs border-r border-black">Turns</div>
                             {[...Array(5)].map((_, i) => <input key={i} className="border-r border-black last:border-none text-center w-full" />)}
                        </div>
                        <div className="grid grid-cols-[2fr_repeat(5,1fr)]">
                            <div className="p-1 text-xs border-r border-black">Parking/Backing</div>
                             {[...Array(5)].map((_, i) => <input key={i} className="border-r border-black last:border-none text-center w-full" />)}
                        </div>
                     </div>
                 </div>

                 <div className="bg-gray-100 border-b border-black p-1 font-bold text-center">Knowledge (Cognitive) Skills</div>
                 {["Judgment - Time", "Judgment - Space", "Judgment - ROW", "Decision-Making", "Rules of the Road", "Commentary"].map(skill => (
                      <div key={skill} className="grid grid-cols-[3fr_repeat(5,1fr)] border-b border-gray-400">
                         <div className="p-1 border-r border-black">{skill}</div>
                         <div className="grid grid-cols-5">
                             {[...Array(5)].map((_, i) => <div key={i} className="border-r border-black last:border-none p-0"><input className={evalInputClass} /></div>)}
                         </div>
                     </div>
                 ))}

                 <div className="bg-gray-100 border-b border-black p-1 font-bold text-center">Awareness (Perceptual) Skills</div>
                 {["Hazard Awareness", "Hazard Management", "Risk Assessment", "Commentary"].map(skill => (
                      <div key={skill} className="grid grid-cols-[3fr_repeat(5,1fr)] border-b border-gray-400">
                         <div className="p-1 border-r border-black">{skill}</div>
                         <div className="grid grid-cols-5">
                             {[...Array(5)].map((_, i) => <div key={i} className="border-r border-black last:border-none p-0"><input className={evalInputClass} /></div>)}
                         </div>
                     </div>
                 ))}
                 
                 <div className="p-2 text-xs">
                    <p className="font-bold">Grades - Overall Skills</p>
                    <p>4.0 - Student vehicle-handling and/or theory require <strong>continuous</strong> instructor assistance</p>
                    <p>5.0 - Student vehicle-handling and/or theory require <strong>frequent</strong> instructor assistance</p>
                    <p>6.0 - Student vehicle-handling, theory, and perceptual skills require <strong>occasional</strong> instructor assistance</p>
                    <p>7.0 - Student vehicle-handling, theory and perceptual skills require <strong>minimal</strong> instructor assistance</p>
                    <p>7.5 - Student performs <strong>independently</strong> 75% of the time</p>
                    <p>8.0 - Student performs <strong>independently</strong> 80% of the time</p>
                    <p>9.0 - Student performs <strong>independently</strong> 90% of the time</p>
                 </div>
            </div>

            {/* Right: Instructor Codes - New Activity */}
            <div className="border border-black">
                <div className="bg-gray-200 border-b border-black p-1 font-bold text-center" style={{ printColorAdjust: 'exact', WebkitPrintColorAdjust: 'exact' }}>Instructor Codes - New Activity</div>
                <div className="p-1 text-[10px] border-b border-black">
                    1 - Theory (Cognitive) | 2 - Demo (Psychomotor) | 3 - Both
                </div>
                
                <div className="grid grid-cols-[repeat(5,20px)_1fr]">
                     <div className="col-span-5 grid grid-cols-5 text-center font-bold border-b border-black">
                         {[2,4,6,8,10].map(h => <div key={h} className="border-r border-gray-400">{h}</div>)}
                     </div>
                     <div className="font-bold p-1 border-b border-black text-center">Suggested Lesson Plan</div>
                </div>

                {[
                    "Pre-trip/Under the Hood", "Basic Habits (Interior)", "Demonstration Drive/Demo", "Start and Stop", "Lane Changing/Blind Zone", "Turns - Right", "Turns - Left", 
                    "Lesson 1 Review", "Lesson 2 Preview", "Intersections (Control/Uncontrol)", "Multi-Lane Roadways", "Turns - Controlled Int", "Turns - Multi-Lane Int", 
                    "Clutch/Shifting", "Backing", "Parallel Parking", "Angle/Perp Parking", "Up/Down Hill Parking", "Lesson 2 Review", "Lesson 3 Preview", 
                    "One-Way Streets", "Railway Crossings", "Traffic Circles", "Highway/Freeway Driving", "Hazard Awareness/Commentary", "Hazard Management/Commentary", 
                    "Lesson 3 Review", "Lesson 4 Preview", "Merging/Weave Zones", "2 & 3 Point Turns", "Adverse Conditions/After Dark", "Lesson 4 Review", 
                    "Lesson 5 Preview", "Downtown", "Independent Driving", "Lesson 5 Review", "Overall In-Vehicle Review"
                ].map((activity, idx) => (
                    <div key={idx} className="grid grid-cols-[repeat(5,20px)_1fr] border-b border-gray-200 hover:bg-gray-50">
                        {[...Array(5)].map((_, i) => (
                            <div key={i} className="border-r border-gray-300 flex items-center justify-center">
                                <input type="checkbox" className="w-3 h-3" />
                            </div>
                        ))}
                        <div className="p-1 pl-2 text-xs truncate">{activity}</div>
                    </div>
                ))}
            </div>
        </div>
      </div>

      {/* ======================= DRIVER EVALUATION REPORT (P5 - Comments) ======================= */}
      <div className="break-before-page bg-white p-8 md:p-12 shadow-xl border border-gray-200 print:shadow-none print:border-none print:p-0 text-xs">
          <h1 className="text-xl font-bold text-center mb-4">Comments</h1>
          
          <div className="grid grid-cols-[100px_repeat(5,1fr)] border border-black">
              {/* Header */}
              <div className="border-r border-black p-2 font-bold bg-gray-200"></div>
              {["Lesson 1 (1-2)", "Lesson 2 (3-4)", "Lesson 3 (5-6)", "Lesson 4 (7-8)", "Lesson 5 (9-10)"].map(l => (
                  <div key={l} className="border-r border-black last:border-none p-2 font-bold text-center bg-gray-200" style={{ printColorAdjust: 'exact', WebkitPrintColorAdjust: 'exact' }}>
                      {l}
                  </div>
              ))}

              {/* Psychomotor Row */}
              <div className="border-r border-black border-t border-black p-2 font-bold flex items-center justify-center bg-gray-100 rotate-180 md:rotate-0 writing-mode-vertical md:writing-mode-horizontal">
                  <span className="md:transform md:-rotate-90">Psychomotor</span>
              </div>
              {[...Array(5)].map((_, i) => (
                  <textarea key={i} className="border-r border-black border-t border-black last:border-none p-2 h-40 w-full resize-none focus:outline-none" placeholder="Steering, Braking, Speed, Scanning..." />
              ))}

              {/* Cognitive Row */}
               <div className="border-r border-black border-t border-black p-2 font-bold flex items-center justify-center bg-gray-100">
                  <span className="md:transform md:-rotate-90">Cognitive</span>
              </div>
              {[...Array(5)].map((_, i) => (
                  <textarea key={i} className="border-r border-black border-t border-black last:border-none p-2 h-40 w-full resize-none focus:outline-none" placeholder="Judgment, Decision-Making, Rules..." />
              ))}

              {/* Perceptual Row */}
               <div className="border-r border-black border-t border-black p-2 font-bold flex items-center justify-center bg-gray-100">
                  <span className="md:transform md:-rotate-90">Perceptual</span>
              </div>
              {[...Array(5)].map((_, i) => (
                  <textarea key={i} className="border-r border-black border-t border-black last:border-none p-2 h-40 w-full resize-none focus:outline-none" placeholder="Hazard Awareness, Risk Assessment..." />
              ))}
          </div>
      </div>

    </div>
  );
};

export default RegistrationPage;
