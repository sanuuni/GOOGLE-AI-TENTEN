
import React from 'react';
import { Link } from 'react-router-dom'; // Import Link

const ServicesPage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8 flex-grow">
      <h1 className="text-5xl font-extrabold text-blue-800 text-center mb-12">Our Driving Services</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
        {/* Service Card 1 */}
        <div className="bg-white rounded-lg shadow-xl p-8 border border-blue-100 transform hover:scale-105 transition-transform duration-300">
          <h2 className="text-3xl font-bold text-blue-700 mb-4">Beginner Driving Lessons</h2>
          <p className="text-gray-700 mb-6 leading-relaxed">
            Perfect for those with little to no prior driving experience. Our comprehensive beginner package covers all the basics, from vehicle controls to fundamental road rules.
          </p>
          {/* Enhanced content starts here */}
          <div className="text-gray-700 mb-6 leading-relaxed bg-blue-50 p-4 rounded-lg border border-blue-100 text-sm italic">
            <p className="mb-2">
              Our comprehensive Beginner Driving Lessons are meticulously designed to meet and exceed the minimum driver education standards set by Alberta Transportation for certificate eligibility. This foundational program is structured to provide you with a thorough and well-rounded driving education:
            </p>
            <ul className="list-disc list-inside ml-4 mb-2 space-y-1">
              <li>
                <strong>15 Hours of Theory Course:</strong> Delivered online, this component covers essential road knowledge, traffic laws, and defensive driving principles. A minimum of 80% online completion is required.
              </li>
              <li>
                <strong>10 Hours of Behind-the-Wheel Training:</strong> Conducted over 5 practical lessons, each 2 hours in duration, with our certified instructors. These sessions focus on developing critical on-road skills and safe driving habits. A minimum of 75% in-vehicle competency is required.
              </li>
            </ul>
            <p>
              Upon successful completion of this program, you will receive an official Alberta Transportation-approved certificate. This not only validates your enhanced driving skills but also qualifies you for significant reductions in your driver's insurance rates, offering long-term financial benefits and peace of mind.
            </p>
          </div>
          {/* Insurance Benefits Section - NEW */}
          <div className="bg-green-50 p-4 rounded-lg border border-green-100 text-sm italic mt-4">
            <h4 className="font-bold text-green-700 mb-2">Insurance Benefits</h4>
            <p>
              Upon successful completion of our Beginner Driving Lessons, you will receive an official Alberta Transportation-approved certificate. This certificate is widely recognized by insurance providers and can lead to significant reductions in your driver's insurance rates, offering long-term financial benefits.
            </p>
          </div>
          {/* Enhanced content ends here */}
          <ul className="list-disc list-inside text-gray-600 space-y-2 mb-6 mt-6">
            <li>Introduction to car controls</li>
            <li>Basic maneuvering and parking</li>
            <li>Traffic laws and safety procedures</li>
            <li>Preparation for permit test</li>
          </ul>
          <div className="text-right">
            <Link to="/pricing" className="text-blue-600 hover:text-blue-800 font-semibold transition-colors duration-200">View Pricing &rarr;</Link>
          </div>
        </div>

        {/* Service Card 2 */}
        <div className="bg-white rounded-lg shadow-xl p-8 border border-blue-100 transform hover:scale-105 transition-transform duration-300">
          <h2 className="text-3xl font-bold text-blue-700 mb-4">Intermediate Driving Courses</h2>
          <p className="text-gray-700 mb-6 leading-relaxed">
            Our Intermediate Driving Courses are meticulously crafted for drivers who have mastered the fundamentals and are ready to advance their skills to navigate more intricate and demanding road conditions. This program is designed to transform competent drivers into truly confident and proficient operators, capable of handling complex urban traffic, multi-lane highways, and varying weather scenarios with precision and calm. Our highly experienced instructors will guide you through advanced defensive driving techniques, risk assessment, and decision-making strategies, ensuring you develop a proactive approach to driving. Elevate your road awareness, enhance your maneuverability, and solidify your confidence, becoming a safer and more capable driver prepared for anything the road presents.
          </p>
          <ul className="list-disc list-inside text-gray-600 space-y-2 mb-6">
            <li>Advanced urban driving techniques</li>
            <li>Highway driving instruction</li>
            <li>Defensive driving strategies</li>
            <li>Mock driving tests</li>
          </ul>
          <div className="text-right">
            <Link to="/pricing" className="text-blue-600 hover:text-blue-800 font-semibold transition-colors duration-200">View Pricing &rarr;</Link>
          </div>
        </div>

        {/* Service Card 3 */}
        <div className="bg-white rounded-lg shadow-xl p-8 border border-blue-100 transform hover:scale-105 transition-transform duration-300">
          <h2 className="text-3xl font-bold text-blue-700 mb-4">Refresher Driving Lessons</h2>
          <p className="text-gray-700 mb-6 leading-relaxed">
            Ideal for licensed drivers who haven't driven in a while or need to brush up on specific skills, such as parallel parking or navigating new areas.
          </p>
          <ul className="list-disc list-inside text-gray-600 space-y-2 mb-6">
            <li>Customized lesson plans</li>
            <li>Focus on specific areas of concern</li>
            <li>Rebuilding confidence behind the wheel</li>
            <li>Latest road rule updates</li>
          </ul>
          <div className="text-right">
            <Link to="/pricing" className="text-blue-600 hover:text-blue-800 font-semibold transition-colors duration-200">View Pricing &rarr;</Link>
          </div>
        </div>

        {/* Service Card 4 */}
        <div className="bg-white rounded-lg shadow-xl p-8 border border-blue-100 transform hover:scale-105 transition-transform duration-300">
          <h2 className="text-3xl font-bold text-blue-700 mb-4">Emergency Braking & Evasive Maneuvers</h2>
          <p className="text-gray-700 mb-6 leading-relaxed">
            Learn crucial skills to react safely and effectively in unexpected road situations, minimizing risks and preventing accidents.
          </p>
          <ul className="list-disc list-inside text-gray-600 space-y-2 mb-6">
            <li>Controlled emergency braking</li>
            <li>Hazard recognition and avoidance</li>
            <li>Skid control techniques</li>
            <li>Decision-making under pressure</li>
          </ul>
          <div className="text-right">
            <Link to="/pricing" className="text-blue-600 hover:text-blue-800 font-semibold transition-colors duration-200">View Pricing &rarr;</Link>
          </div>
        </div>

        {/* Service Card 5 */}
        <div className="bg-white rounded-lg shadow-xl p-8 border border-blue-100 transform hover:scale-105 transition-transform duration-300">
          <h2 className="text-3xl font-bold text-blue-700 mb-4">Winter Driving Skills</h2>
          <p className="text-gray-700 mb-6 leading-relaxed">
            Master the art of driving safely in challenging winter conditions, including snow, ice, and reduced visibility.
          </p>
          <ul className="list-disc list-inside text-gray-600 space-y-2 mb-6">
            <li>Traction management on slippery roads</li>
            <li>Safe braking and turning in snow</li>
            <li>Visibility and hazard awareness</li>
            <li>Cold weather vehicle maintenance tips</li>
          </ul>
          <div className="text-right">
            <Link to="/pricing" className="text-blue-600 hover:text-blue-800 font-semibold transition-colors duration-200">View Pricing &rarr;</Link>
          </div>
        </div>

        {/* Service Card 6 */}
        <div className="bg-white rounded-lg shadow-xl p-8 border border-blue-100 transform hover:scale-105 transition-transform duration-300">
          <h2 className="text-3xl font-bold text-blue-700 mb-4">Parallel Parking Mastery</h2>
          <p className="text-gray-700 mb-6 leading-relaxed">
            Conquer one of the most feared driving maneuvers with our dedicated parallel parking clinic. Learn tips and tricks for perfection.
          </p>
          <ul className="list-disc list-inside text-gray-600 space-y-2 mb-6">
            <li>Step-by-step parallel parking guide</li>
            <li>Spatial awareness and judgment</li>
            <li>Practice in various scenarios</li>
            <li>Overcoming parking anxiety</li>
          </ul>
          <div className="text-right">
            <Link to="/pricing" className="text-blue-600 hover:text-blue-800 font-semibold transition-colors duration-200">View Pricing &rarr;</Link>
          </div>
        </div>
      </div>

      <div className="mt-16 text-center">
        <p className="text-xl text-gray-800">
          Have specific needs? We can customize a lesson plan just for you!{' '}
          <Link to="/contact" className="text-blue-700 hover:text-blue-900 font-bold transition-colors duration-200">Contact us</Link> to discuss.
        </p>
      </div>
    </div>
  );
};

export default ServicesPage;