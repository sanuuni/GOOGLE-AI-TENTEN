
import React from 'react';
import { SCHOOL_NAME } from '../constants';

const TermsPage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8 flex-grow">
      <div className="max-w-4xl mx-auto bg-white p-8 md:p-12 shadow-md border border-gray-100 rounded-lg">
        <h1 className="text-4xl font-extrabold text-blue-800 mb-8">Terms and Conditions</h1>
        <p className="text-gray-600 mb-8 text-sm">Last Updated: {new Date().toLocaleDateString()}</p>

        <div className="space-y-6 text-gray-700 leading-relaxed">
          <section>
            <h2 className="text-2xl font-bold text-blue-700 mb-4">1. Agreement to Terms</h2>
            <p>
              These Terms and Conditions constitute a legally binding agreement made between you, whether personally or on behalf of an entity (“you”) and {SCHOOL_NAME} (“we,” “us” or “our”), concerning your access to and use of our website and services.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-blue-700 mb-4">2. Services</h2>
            <p>
              We provide driving instruction, road test car rentals, and insurance reduction courses. We reserve the right to withdraw or modify our services at any time without prior notice.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-blue-700 mb-4">3. Cancellation and Refund Policy</h2>
            <ul className="list-disc list-inside ml-4 mt-2 space-y-2">
              <li><strong>Lesson Cancellation:</strong> Cancellations must be made at least 24 hours in advance. Failure to do so will result in a $55.00 cancellation fee.</li>
              <li><strong>Refunds:</strong> Refunds for prepaid packages may be subject to administrative fees. Unused portions of packages are non-transferable.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-blue-700 mb-4">4. Student Responsibilities</h2>
            <p>
              Students are required to:
            </p>
            <ul className="list-disc list-inside ml-4 mt-2 space-y-2">
              <li>Possess a valid Alberta Learner's License (Class 7) or higher during all in-vehicle training.</li>
              <li>Arrive on time for all scheduled lessons.</li>
              <li>Refrain from using electronic devices during lessons.</li>
              <li>Be free from the influence of alcohol or drugs.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-blue-700 mb-4">5. Limitation of Liability</h2>
            <p>
              In no event will we be liable to you or any third party for any direct, indirect, consequential, exemplary, incidental, special, or punitive damages arising from your use of the site or our services, even if we have been advised of the possibility of such damages.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-blue-700 mb-4">6. Contact Us</h2>
            <p>
              To resolve a complaint regarding the Site or to receive further information regarding use of the Site, please contact us at:
            </p>
            <div className="mt-4 bg-blue-50 p-4 rounded-lg">
              <p><strong>{SCHOOL_NAME}</strong></p>
              <p>Email: sankatenten@gmail.com</p>
              <p>Phone: 403-404-1010</p>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default TermsPage;
